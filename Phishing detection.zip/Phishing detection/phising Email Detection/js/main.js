document.addEventListener('DOMContentLoaded', async function () {
    var contactForm = async function () {
        var form = document.getElementById('contactForm');

        if (form !== null) {
            form.addEventListener('submit', async function (event) {
                event.preventDefault();
                await validateForm();
            });
        }

        async function validateForm() {
            var emailInput = document.getElementById('email');
            const spinnerBtn=document.getElementById("cover-spin");
            spinnerBtn.style.display = "block"; 
            if (emailInput.value.trim() === '' || !isValidEmail(emailInput.value.trim())) {
                alert('Please enter a valid email address');
                spinnerBtn.style.display = "none"; 
                return;
            }

            try {
                const response = await fetch('http://localhost:3000/check-email', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ email: emailInput.value.trim() }),
                });

                if (!response.ok) {
                    spinnerBtn.style.display = "none"; 
                    throw new Error('Network response was not ok');
                }
setTimeout(async() => {
    emailInput.value=""
    const result = await response.json();
    let message = result.isPhishing ? 'Phishing Email Detected!' : 'Not a Phishing Email';
    spinnerBtn.style.display = "none"; 

    document.getElementById('overlay').style.display = 'block';
    let contentArea=document.querySelector(".boxConent");
    contentArea.textContent=message;
}, 3000);
              
            } catch (error) {
                spinnerBtn.style.display = "none"; 
                console.error('There was a problem with the fetch operation:', error);
                alert('Error occurred while checking the email. Please try again.');
            }
        }

        function isValidEmail(email) {
            // You can use a more sophisticated email validation regex if needed
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }
    };

    await contactForm();

    document.getElementById('cancelButton').addEventListener('click', function() {
        document.getElementById('overlay').style.display = 'none';
      });
      
});
