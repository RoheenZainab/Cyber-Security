const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const cors = require('cors'); 
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());

// Endpoint to check if a URL is phishing
app.post('/check-email', async (req, res) => {
  const emailToCheck = req.body.email;

  if (!emailToCheck) {
    return res.status(400).json({ error: 'Email is required' });
  }

  try {
    const apiKey = 'd87ae793ee83883d79ab810ff650df85c05c721c0196fa486dd39acc711a27e9'; // Replace with your OTX API key
    const apiUrl = `https://otx.alienvault.com/api/v1/indicators/url/${encodeURIComponent(emailToCheck)}/url_list?limit=1`;

    const response = await axios.get(apiUrl, {
      headers: {
        'X-OTX-API-KEY': apiKey,
      },
    });

    const isPhishing = response.data.url_list.length > 0;
    res.json({ isPhishing });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
console.log("app is running");
