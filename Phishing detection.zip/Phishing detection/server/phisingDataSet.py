import psycopg2
import pandas as pd
from sqlalchemy import create_engine

# Connect to your PostgreSQL database
conn = psycopg2.connect(
    database="phishing-datase",
    user="postgres",
    password="1122",
    host="localhost",
    port="5433"
)

# Create a cursor
cursor = conn.cursor()

# Read your dataset (assuming it's in a CSV file)
df = pd.read_csv(r"C:\Users\Usama Shabbir\Desktop\cyber_python\Phishing_Legitimate_full.csv")

# Define the column data types for PostgreSQL
column_data_types = {
    "id": "serial PRIMARY KEY",
    "NumDots": "integer",
    "SubdomainLevel": "integer",
    "PathLevel": "integer",
    "UrlLength": "integer",
    "NumDash": "integer",
    "NumDashInHostname": "integer",
    "AtSymbol": "integer",
    "TildeSymbol": "integer",
    "NumUnderscore": "integer",
    "NumPercent": "integer",
    "NumQueryComponents": "integer",
    "NumAmpersand": "integer",
    "NumHash": "integer",
    "NumNumericChars": "integer",
    "NoHttps": "integer",
    "RandomString": "integer",
    "IpAddress": "integer",
    "DomainInSubdomains": "integer",
    "DomainInPaths": "integer",
    "HttpsInHostname": "integer",
    "HostnameLength": "integer",
    "PathLength": "integer",
    "QueryLength": "integer",
    "DoubleSlashInPath": "integer",
    "NumSensitiveWords": "integer",
    "EmbeddedBrandName": "integer",
    "PctExtHyperlinks": "integer",
    "PctExtResourceUrls": "integer",
    "ExtFavicon": "integer",
    "InsecureForms": "integer",
    "RelativeFormAction": "integer",
    "ExtFormAction": "integer",
    "AbnormalFormAction": "integer",
    "PctNullSelfRedirectHyperlinks": "integer",
    "FrequentDomainNameMismatch": "integer",
    "FakeLinkInStatusBar": "integer",
    "RightClickDisabled": "integer",
    "PopUpWindow": "integer",
    "SubmitInfoToEmail": "integer",
    "IframeOrFrame": "integer",
    "MissingTitle": "integer",
    "ImagesOnlyInForm": "integer",
    "SubdomainLevelRT": "integer",
    "UrlLengthRT": "integer",
    "PctExtResourceUrlsRT": "integer",
    "AbnormalExtFormActionR": "integer",
    "ExtMetaScriptLinkRT": "integer",
    "PctExtNullSelfRedirectHyperlinksRT": "integer",
    "CLASS_LABEL": "integer"
}


# Create the table based on your dataset structure
create_table_query = f'''
    CREATE TABLE IF NOT EXISTS EmailDataSet (
        {", ".join([f"{col} {data_type}" for col, data_type in column_data_types.items()])}
    );
'''
cursor.execute(create_table_query)

# Commit the transaction
conn.commit()

# Close the cursor
cursor.close()

# Close the database connection
conn.close()

# Create SQLAlchemy engine
engine = create_engine("postgresql://postgres:1122@localhost:5433/phishing-datase")

# Write the DataFrame to a PostgreSQL table
df.to_sql("EmailDataSet", engine, index=False, if_exists="replace", dtype=column_data_types)
